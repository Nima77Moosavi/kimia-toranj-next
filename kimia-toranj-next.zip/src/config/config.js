export const BASE_URL = "http://127.0.0.1:8000";
// export const API_URL = "https://api.kimiatoranj.com/";
export const API_URL = "https://api.kimiatoranj.com/";
