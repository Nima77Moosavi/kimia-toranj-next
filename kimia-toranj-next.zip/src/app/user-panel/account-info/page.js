// app/user-panel/account-info/page.jsx
"use client";

import UserInfoForm from "@/components/UserInfoForm/UserInfoForm";

export default function AccountInfoPage() {
  return <UserInfoForm />;
}
