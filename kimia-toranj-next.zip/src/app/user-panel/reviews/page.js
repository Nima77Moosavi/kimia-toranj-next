"use client";

import ReviewsList from "@/components/ReviewsList/ReviewsList";

export default function UserReviewsPage() {
  return <ReviewsList />;
}
