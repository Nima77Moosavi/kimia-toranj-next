// app/user-panel/wishlist/page.jsx
"use client";

import WishlistItems from "@/components/WishlistItems/WishlistItems";

export default function WishlistPage() {
  return <WishlistItems />;
}
